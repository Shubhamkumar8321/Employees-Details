/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package emp.Dao;

import emp.DBuilt.DBConnection;
import emp.pojo.EmpPojo;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author shubh
 */
public class EmpDAO {
    public static boolean addEmp(EmpPojo e)throws SQLException{
        Connection conn =DBConnection.getConnection();
        PreparedStatement ps=conn.prepareStatement("Insert into employee values(?,?,?)");
        ps.setInt(1,e.getEmpno());
        ps.setString(2,e.getEmpname());
        ps.setDouble(3,e.getEmpsal());
        int res=ps.executeUpdate();
        return res==1;
    }
    public static List<EmpPojo>getAllEmployee()throws SQLException{
        Connection conn =DBConnection.getConnection();
        Statement st=conn.createStatement();
        List<EmpPojo>empList=new ArrayList<>();
        ResultSet rs=st.executeQuery("Select*from employee");
        while(rs.next()){
            EmpPojo e=new EmpPojo();
            e.setEmpno(rs.getInt(1));
            e.setEmpname(rs.getString(2));
            e.setEmpsal(rs.getDouble(3));
            empList.add(e);
        }
        return empList;
    }
    public static EmpPojo findEmpbyID(int id) throws SQLException{
        Connection conn =DBConnection.getConnection();
        PreparedStatement ps=conn.prepareStatement("select * from employee where Empno=?");
        ps.setInt(1,id);
        ResultSet rs=ps.executeQuery();
        EmpPojo emp=null;
        if(rs.next()){
            emp=new EmpPojo();
            emp.setEmpno(id);
            emp.setEmpname(rs.getString(2));
            emp.setEmpsal(rs.getDouble(3));
        }
        return emp;
    }
}
