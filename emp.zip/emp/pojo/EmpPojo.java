/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package emp.pojo;

import java.sql.SQLException;

/**
 *
 * @author shubh
 */
public class EmpPojo {
    private int Empno;
    private String Empname;
    private double Empsal;
    public EmpPojo(int Empno, String Empname, double Empsal) {
        this.Empno = Empno;
        this.Empname = Empname;
        this.Empsal = Empsal;
    }

    public EmpPojo() throws SQLException {
        
    }

    public int getEmpno() {
        return Empno;
    }

    public void setEmpno(int Empno) {
        this.Empno = Empno;
    }

    public String getEmpname() {
        return Empname;
    }

    public void setEmpname(String Empname) {
        this.Empname = Empname;
    }

    public double getEmpsal() {
        return Empsal;
    }

    public void setEmpsal(double Empsal) {
        this.Empsal = Empsal;
    }
    
}
